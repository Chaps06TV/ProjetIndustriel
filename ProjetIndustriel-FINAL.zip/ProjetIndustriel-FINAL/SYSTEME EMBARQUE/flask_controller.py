from Hardware import controller
from flask import Flask, render_template, request
app = Flask(__name__)
@app.route('/')
def DataEntry():
	return render_template('index.html')
@app.route('/result',methods = ['POST', 'GET'])
def result():
	if request.form.get("niveau"):
		print("Start Pression" + controller.getWater())
		result = request.form
	if request.form.get("temp"):
		print("Start Pression" + controller.get())
		result = request.form
	if request.form.get("data"):
		print("Envoi des donnes")
	#return 'Blood Pressure state: %s' % system.BloodPressureState["state"]
	