#from Hardware/controller import getTemp, getWater, pushToLocalDB
#from Hardware/controller import Controller
from Hardware import controller
import cmd
import os
#import controller

class InterpreteurCommande(cmd.Cmd):
	"""Shell pour controlleur industriel"""
	prompt = '> '
	intro = "Welcome Industrial"
	doc_header = 'doc_header'
	misc_header = 'misc_header'
	undoc_header = 'undoc_header'
	ruler = '-'
	
	def cmdloop(self, intro=None):
		#print ('cmdloop(%s)' % intro)
		return cmd.Cmd.cmdloop(self, intro)
	def do_gettemp(self, line):
		print (controller.controller.getTemp())
	def do_getlevel(self, line):
		print (controller.controller.getWater())
	def do_savecuruserdata(self, line):
		controller.controller.pushToLocalDB(
			controller.controller.getDate(), 
			controller.controller.getTemp(), 
			controller.controller.getWater()
		)
	def do_cleardb(self, line):
		controller.controller.clearLocalDB()
	def do_showdb(self, line):
		print controller.controller.extractLocalDB()
	def do_configdate(self, format):
		controller.controller.setDate(format)
	def do_getdate(self, line):
		print(controller.controller.getDate())
	def do_senddata(ipserver, line):
		print ('senddata ipserver')
	def do_EOF(self, line):
		"Exit"
		return True
	
if __name__ == '__main__':
	InterpreteurCommande().cmdloop()
	
	