

## Git Commands
 - git clone https://github.com/purpledxd/ORD11167.git
     - If certification error, run this command: export GIT_SSL_NO_VERIFY=1
	 - Clone the repository
	 - Login when prompted...
 - git add -A
	 - Add changed files / new files to index
 - git commit -a
	 - Commit index to local repository
	 - Add commit message (if vim, :wq to save & exit, :q! to cancel)
 - git push
	 - Push the local repository to GitHub repository
 - git pull
	- Get GitHub repo to local

 ## Raspberry PI
  - enable dhcp 	
	 - $ service dhcpcd start
 - voir addresse IP
	 - $ ifconfig
 - enable ssh
	 - $ raspi-config
	 - interfaces
	 - SSH
	 - Enable SSH
 - repertoire du projet
	 - ~/Justyn/ORD11167
