from threading import Thread, RLock
from time import sleep
from socketIO_client import SocketIO

import controller

lock = RLock()	

class WebThread(Thread):
        socketIO = SocketIO('chaps06.ddns.net', 80)

	def __init__(self):
		Thread.__init__(self)
		self.start()
		
	def run(self):
		self.socketIO.on('synchroniserSysEmb', self.on_synchro)
		self.socketIO.wait()
		
	def on_synchro(self):
		json = controller.controller.extractLocalDB()
		self.socketIO.emit('reponseSysEmb', { 'productId' : 24, 'json': json })
                controller.controller.clearLocalDB()

class LocalThread(Thread):
	def __init__(self):
		Thread.__init__(self)
		self.start()
		
	def run(self):
		while True:
			temp = controller.controller.getTemp()
			water = controller.controller.getWater()
			date = controller.controller.getDate()
			with lock:
				controller.controller.pushToLocalDB(date, temp, water)
			sleep(3600)
		
thread_1 = LocalThread()
thread_2 = WebThread()
thread_1.join()
thread_2.join()
