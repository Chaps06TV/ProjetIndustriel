from datetime import datetime, timedelta
import time
import sqlite3 as lite
import json

from ADC.ADS1015 import ADS1015 as ADC
from Thermometre import MLX as MLX

waterDriver = ADC()
tempDriver = MLX.MLX()



class Controller():		
	timediff = timedelta(seconds=0);
	
	#on retourne la temperature avec la fonction du capteur
	def getTemp(self):
		return tempDriver.get_obj_temp()
		
	#On appel la fonction qui retourne le niveau d'eau du capteur 	
	def getWater(self):		
		return waterDriver.read_level()
		
	def pushToLocalDB(self, date, temp, water):
		#temp niveau date
		conn = lite.connect('/home/pi/Justyn/ORD11167/Hardware/industriel.db')
		with conn:
			cur = conn.cursor()
			query = "INSERT INTO tblProduction VALUES(" + str(temp) + ", " + str(water) + ", '" + str(date) + "');"
			cur.execute(query)
	
	def clearLocalDB(self):
		conn = lite.connect('/home/pi/Justyn/ORD11167/Hardware/industriel.db')
		with conn:
			cur = conn.cursor()
			query = "DELETE FROM tblProduction"
			cur.execute(query)
		
	def getDate(self):
		date = datetime.now() - self.timediff
		return date.strftime('%Y-%m-%d')
		
	def setDate(self, date):
		self.timediff = datetime.now() - datetime.strptime(date, '%Y-%m-%d')
		
	def extractLocalDB(self):
		conn = lite.connect('/home/pi/Justyn/ORD11167/Hardware/industriel.db')
		conn.row_factory = lite.Row
		with conn:
			cur = conn.cursor()
			cur.execute("SELECT * FROM tblProduction")
			data = cur.fetchall()
			return json.dumps([dict(ix) for ix in data])
		
controller = Controller()
