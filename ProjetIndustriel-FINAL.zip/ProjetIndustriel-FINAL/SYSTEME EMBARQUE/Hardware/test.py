import sqlite3 as lite
import controller

conn = lite.connect('industriel.db')
cur = conn.cursor()

print(controller.controller.extractLocalDB())

controller.controller.pushToLocalDB(controller.controller.getDate(), controller.controller.getTemp(), controller.controller.getWater())
	
print(controller.controller.extractLocalDB())
	
controller.controller.clearLocalDB()

print(controller.controller.extractLocalDB())