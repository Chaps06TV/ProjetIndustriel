-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  lun. 01 avr. 2019 à 19:29
-- Version du serveur :  10.1.38-MariaDB
-- Version de PHP :  7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `bdd_industriel`
--

DELIMITER $$
--
-- Procédures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `production_detail` (IN `clientIdIn` INT)  BEGIN
	SELECT p.productId, nom, temperature, niveau, dateProduction
	FROM tblProduction p
	INNER JOIN (SELECT productId, temperature, niveau, dateProduction
			FROM tblDetail
            		ORDER BY dateProduction ASC LIMIT 9223372036854775807) d
	ON p.productId = d.productId
	WHERE clientId = clientIdIn
	GROUP BY productId;
END$$

--
-- Fonctions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `sysEmbBackup` (`clientIdIn` INT) RETURNS INT(11) BEGIN
	
	INSERT INTO tblProduction (clientId) VALUES (clientIdIn);
    RETURN (SELECT LAST_INSERT_ID() FROM tblProduction LIMIT 1);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `tblclient`
--

CREATE TABLE `tblclient` (
  `clientId` int(10) UNSIGNED NOT NULL,
  `prenom` varchar(20) DEFAULT NULL,
  `nom` varchar(30) DEFAULT NULL,
  `adresse` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tblclient`
--

INSERT INTO `tblclient` (`clientId`, `prenom`, `nom`, `adresse`) VALUES
(5, 'Marc', 'Lachance', '101 Goldenrod Dr, Ottawa'),
(6, 'Sylvain', 'Deschaines', '101 Colonel By dr, Ottawa'),
(7, 'Richard', 'Latendresse', '2 Winner Road, Shawinigan'),
(8, 'Justin', 'Lafleur', '666 WinXp Avenue, NY'),
(9, 'Jo', 'Gagnon', '123 noppe st'),
(10, 'Maxime', 'Chartrand', '1234 abc'),
(11, 'Dany', 'Lapointe', '123 new street'),
(12, 'Luc', 'Gogo', '700 rue Gros'),
(13, 'Mathieu', 'Lepointe', '123 fake st');

-- --------------------------------------------------------

--
-- Structure de la table `tbldetail`
--

CREATE TABLE `tbldetail` (
  `productId` int(10) UNSIGNED NOT NULL,
  `temperature` int(11) DEFAULT NULL,
  `dateProduction` date DEFAULT NULL,
  `niveau` float UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tbldetail`
--

INSERT INTO `tbldetail` (`productId`, `temperature`, `dateProduction`, `niveau`) VALUES
(12, 10, '2019-03-19', 20.5),
(12, 20, '2019-03-20', 26),
(12, 0, '2019-03-18', 23),
(13, 45, '2019-03-22', 23),
(12, 45, '2019-03-20', 12),
(13, 61, '2019-03-21', 85),
(14, 65, '2019-03-25', 12),
(15, 58, '2019-03-22', 24),
(22, 86, '2019-03-20', 125),
(24, 45, '2019-03-20', 96),
(25, 59, '2019-03-20', 10),
(26, 48, '2019-03-16', 48),
(27, 65, '2019-03-27', 89),
(29, 101, '2019-03-24', 12),
(22, 10, '2019-03-30', 10),
(22, 22, '2018-04-20', 0),
(25, 22, '2018-04-20', 0),
(25, 44, '2018-04-20', 0),
(25, 23, '2018-04-20', 0),
(24, 22, '2018-04-20', 0),
(24, 44, '2018-04-20', 0),
(24, 23, '2018-04-20', 0),
(24, 22, '2018-04-20', 0),
(24, 44, '2018-04-20', 0),
(24, 23, '2019-01-01', 0),
(24, 23, '2018-04-20', 0),
(24, 23, '2018-04-20', 0),
(24, 23, '2018-04-20', 0),
(24, 23, '2019-03-02', 0);

-- --------------------------------------------------------

--
-- Structure de la table `tblproduction`
--

CREATE TABLE `tblproduction` (
  `productId` int(10) UNSIGNED NOT NULL,
  `clientId` int(10) UNSIGNED NOT NULL,
  `quantite` float UNSIGNED DEFAULT NULL,
  `echeance` date DEFAULT NULL,
  `nom` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tblproduction`
--

INSERT INTO `tblproduction` (`productId`, `clientId`, `quantite`, `echeance`, `nom`) VALUES
(12, 6, 170, '2019-03-21', 'Mixture 10'),
(13, 7, 20, '2019-03-19', 'Mixture  2'),
(14, 5, 70, '2019-03-30', 'Mixture 3'),
(15, 7, 48, '2019-03-22', 'Mixture 25'),
(22, 10, 45, '2019-03-21', 'Mix Test'),
(24, 10, 150, '2019-03-30', 'Mix Test 2'),
(25, 10, 20, '2019-03-28', 'Redhot'),
(26, 11, 69, '2019-03-22', 'Sauce Ranch'),
(27, 9, 13, '2019-05-17', 'Mixture 111'),
(28, 12, 12, '2019-04-20', 'Largissement'),
(29, 13, 100, '2019-03-26', 'M45');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `tblclient`
--
ALTER TABLE `tblclient`
  ADD PRIMARY KEY (`clientId`),
  ADD UNIQUE KEY `clientId_UNIQUE` (`clientId`);

--
-- Index pour la table `tblproduction`
--
ALTER TABLE `tblproduction`
  ADD PRIMARY KEY (`productId`),
  ADD UNIQUE KEY `productId_UNIQUE` (`productId`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `tblclient`
--
ALTER TABLE `tblclient`
  MODIFY `clientId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT pour la table `tblproduction`
--
ALTER TABLE `tblproduction`
  MODIFY `productId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
